from django.contrib import admin
from app.models import BlogData
# Register your models here.

admin.site.register(BlogData)